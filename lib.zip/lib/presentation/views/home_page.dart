import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../viewmodels/employee_viewmodel.dart';
import '../routes/app_routes.dart';
import '../widgets/field_input.dart';
import '../widgets/button.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  final salary = TextEditingController();
  int _selectedYears = 1;

void _calculate(){
  final viewmodel = Provider.of<EmployeeViewmodel>(context, listen: false);

  // si el usuario elige 5 ("5 o más"), interpretamos 10 años
  final double yearsForUseCase =
      _selectedYears == 5 ? 10.0 : _selectedYears.toDouble();

  final result = viewmodel.calculateBonus(
    double.parse(salary.text),
    yearsForUseCase,
  );

  Navigator.pushNamed(context, AppRoutes.result, arguments: {
    'result': result,
    'years': _selectedYears,
  });
}


  @override
  void dispose() {
    salary.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: salary,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Salario',
                hintText: 'Ingresa el salario',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Años de servicio:', style: TextStyle(fontWeight: FontWeight.w600)),
            Column(
              children: [1,2,3,4,5].map((y) {
                return RadioListTile<int>(
                  title: Text(y == 5 ? '5 o más' : '$y año${y > 1 ? 's' : ''}'),
                  value: y,
                  groupValue: _selectedYears,
                  onChanged: (val) {
                    if (val != null) setState(() => _selectedYears = val);
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _calculate,
              child: const Text('Calcular'),
            ),
          ],
        ),
      ),
    );
  }
}