import 'package:flutter/material.dart';
import '../../domain/entities/result_employee.dart';

class ResultPage extends StatefulWidget {
  const ResultPage({super.key});

  @override
  State<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  @override
  Widget build(BuildContext context) {
    // 1. Recuperar argumentos tipados
    final args = ModalRoute.of(context)!.settings.arguments
        as Map<String, Object?>;

    final result = args['result'] as ResultEmployee;
    final years  = args['years'] as int;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalle del cálculo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Años de servicio: $years',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 16),
            Text(
              'Bono calculado: \$${result.bonus.toStringAsFixed(2)}',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Salario final: \$${result.finalSalary.toStringAsFixed(2)}',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ],
        ),
      ),
    );
  }
}
