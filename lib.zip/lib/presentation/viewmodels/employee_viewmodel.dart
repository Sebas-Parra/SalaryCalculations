import 'package:flutter/material.dart';
import '../../domain/entities/employee.dart';
import '../../domain/entities/result_employee.dart';
import '../../domain/usescases/compute_bonus.dart';

class EmployeeViewmodel extends ChangeNotifier{
    final CalculateBonusUseCase _calculateBonusUseCase;
    
    EmployeeViewmodel(this._calculateBonusUseCase);
    
    ResultEmployee? resultEmployee;

    ResultEmployee calculateBonus(double salary, double yearsOfExperience){
        final employee = Employee(salary: salary, yearsOfExperience: yearsOfExperience);
        resultEmployee = _calculateBonusUseCase.execute(employee);
        notifyListeners();
        return resultEmployee!;
    }
}