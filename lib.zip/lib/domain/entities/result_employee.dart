class ResultEmployee {
  final double bonus;
  final double finalSalary;

  ResultEmployee({
    required this.bonus, 
    required this.finalSalary});
}