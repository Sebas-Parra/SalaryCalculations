class Employee {

  final double salary;
  final double yearsOfExperience;

  Employee({required this.salary, required this.yearsOfExperience});
}